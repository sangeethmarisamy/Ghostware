
import asyncio
import json
import time

import websockets

try:
    from .detection import DetectionPipeline, unpack_payload
except ImportError:
    from detection import DetectionPipeline, unpack_payload


HOST = "0.0.0.0"
PORT = 8765

pipeline = None
pipeline_error = None


def get_pipeline():
    global pipeline, pipeline_error
    if pipeline is not None:
        return pipeline
    if pipeline_error is not None:
        return None
    try:
        pipeline = DetectionPipeline()
        return pipeline
    except Exception as error:
        pipeline_error = str(error)
        return None


async def handle_client(websocket):
    print("\n" + "=" * 70)
    print("             GHOSTWARE WEBSOCKET RECEIVER")
    print("=" * 70)
    print("Client connected")

    try:
        async for message in websocket:
            try:
                # 1. Receive and parse telemetry.
                data = json.loads(message)

                if not isinstance(data, dict):
                    await websocket.send(json.dumps({
                        "type": "error",
                        "error": "Expected a JSON object"
                    }))
                    continue

                request_id = data.get("request_id") or data.get("event_id")
                detection = get_pipeline()
                if detection is None:
                    await websocket.send(json.dumps({"type": "error", "status": "failed",
                        "request_id": request_id, "error": "Detection pipeline unavailable",
                        "details": pipeline_error}))
                    continue

                if data.get("action") == "verify_evidence":
                    result = await asyncio.to_thread(detection.verify_evidence,
                        data.get("reference", ""), data.get("sha256", ""))
                    await websocket.send(json.dumps({"type": "evidence_verification",
                        "status": "success", "request_id": request_id, "event_id": data.get("event_id"),
                        "detection": result}, ensure_ascii=False, default=str))
                    continue

                events = unpack_payload(data)
                batch_results = []
                batch_started = time.perf_counter()
                for event in events:
                    event_started = time.perf_counter()
                    result = await asyncio.to_thread(detection.process_event, event)
                    result["processing_ms"] = round((time.perf_counter() - event_started) * 1000, 3)
                    batch_results.append(result)
                    response = {"type": "detection_result",
                        "status": "failed" if result.get("persistence") == "failed" else "success",
                        "request_id": result.get("request_id") or request_id,
                        "event_id": result.get("event_id"), "host": result.get("host"),
                        "hostname": result.get("host"), "host_ip": result.get("host_ip"),
                        "source": result.get("source"), "event_type": result.get("event_type"),
                        "prediction": result.get("prediction"), "anomaly_score": result.get("anomaly_score"),
                        "risk_score": result.get("risk_score"), "reason": result.get("reason"),
                        "reasons": result.get("reasons") or ([result.get("reason")] if result.get("reason") else []),
                        "action": result.get("action"), "processing_ms": result.get("processing_ms"),
                        "persistence": result.get("persistence"), "event": event, "detection": result}
                    await websocket.send(json.dumps(response, ensure_ascii=False, default=str))

                if len(batch_results) > 1:
                    summary = {feature: sum(item["event_features"][feature] for item in batch_results)
                        for feature in batch_results[0]["event_features"]}
                    await websocket.send(json.dumps({"type": "batch_summary", "status": "success",
                        "request_id": request_id, "batch_size": len(batch_results),
                        "event_count": len(batch_results), "features": summary,
                        "processing_ms": round((time.perf_counter() - batch_started) * 1000, 3)},
                        ensure_ascii=False, default=str))

            except json.JSONDecodeError:
                await websocket.send(json.dumps({
                    "type": "error",
                    "error": "Invalid JSON received"
                }))
                print("[ERROR] Invalid JSON received")

            except Exception as error:
                print(f"[PROCESSING ERROR] {error}")

                await websocket.send(json.dumps({
                    "type": "error",
                    "status": "failed",
                    "error": str(error)
                }))

    except websockets.exceptions.ConnectionClosed:
        print("Client disconnected")


async def main():
    print("=" * 70)
    print("       GHOSTWARE HYBRID DETECTION ENGINE")
    print("=" * 70)
    print(f"Listening on ws://{HOST}:{PORT}")
    print("Automatic ML detection: enabled")
    print("Evidence verification: enabled")
    print("Client response: enabled")
    print("Waiting for telemetry...")
    print()

    if get_pipeline() is None:
        print(f"Detection pipeline unavailable: {pipeline_error}")

    async with websockets.serve(
        handle_client,
        HOST,
        PORT,
        max_size=1024 * 1024
    ):
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())