"""Compatibility launcher for the canonical Ghostware WebSocket server."""

try:
    from .server import handle_client, main
except ImportError:
    from server import handle_client, main


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
